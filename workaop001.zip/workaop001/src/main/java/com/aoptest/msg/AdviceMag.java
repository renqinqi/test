package com.aoptest.msg;

import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;
import org.aspectj.lang.ProceedingJoinPoint;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
@Aspect
public class AdviceMag {
    @Pointcut("execution(public void com.aoptest.service.impl.UserServiceImpl.sayHello1())")
    public void fun1(){}
    @Pointcut("execution(public void com.aoptest.service.impl.UserServiceImpl.sayHello2())")
    public void fun2(){}
    @Pointcut("execution(public void com.aoptest.service.impl.UserServiceImpl.sayHello3())")
    public void fun3(){}
    @Pointcut("execution(public void com.aoptest.service.impl.UserServiceImpl.sayHello5())")
    public void fun5(){}
    @Pointcut("execution(public void com.aoptest.service.impl.UserServiceImpl.sayHello6())")
    public void fun6(){}

//    方法1执行前,增加输出时间信息
    @Before("fun1()")
    public void msg1(){
        LocalDateTime now=LocalDateTime.now();
        DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formatterDateTime=now.format(formatter);
        System.out.println(formatterDateTime);
    }

//    方法2执行后,不管是否成功,增加一个自定义通知信息
    @After("fun2()")
    public void msg2(){
        System.out.println("后置通知");
    }

//    方法3的执行前后,输出时间信息
    @Around("fun3()")
    public Object mag3(ProceedingJoinPoint point)throws  Throwable{
        LocalDateTime now=LocalDateTime.now();
        DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formatterDateTime=now.format(formatter);
        System.out.println(formatterDateTime);
        Object obj=point.proceed();
        LocalDateTime now2=LocalDateTime.now();
        DateTimeFormatter formatter2=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formatterDateTime2= now2.format(formatter);
        System.out.println(formatterDateTime2);
        return obj;
    }

//    方法5发生异常时,增加一个自定义通知信息
    @AfterThrowing("fun5()")
    public void smg5(){
        System.out.println("这是异常通知");
    }

//    方法6执行后,如果成功,增加一个自定义通知信息
    @AfterReturning("fun6()")
    public void smg6(){
        System.out.println("这是返回通知");
    }

}
