package com.example.service.impl;

import com.example.mapper.OrderMapper;
import com.example.pojo.Order;
import com.example.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderMapper orderMapper;
//增
    @Override
    public Boolean add(Order order) {
        Integer add = orderMapper.add(order);
        return add>0;
    }
//删
    @Override
    public Boolean del(Integer oid) {
        Integer del = orderMapper.del(oid);
        return del>0;
    }
//改
    @Override
    public Boolean update(Order order) {
        Integer update = orderMapper.update(order);
        return update>0;
    }
//查
    @Override
    public Order find(Integer oid) {

        return orderMapper.findById(oid);
    }
//查所有
    @Override
    public List<Order> findall() {
        return orderMapper.findAll();
    }
}
