package com.example.service.impl;

import com.example.mapper.UserMapper;
import com.example.pojo.User;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

//增
    @Override
    public Boolean add(User user) {
        int  row= userMapper.add(user);
        return row>0;
    }

//删
    @Override
    public Boolean del(Integer uid) {
        int row=userMapper.del(uid);
        return row>0;
    }

//改
    @Override
    public Boolean update(User user) {
        int row= userMapper.update(user);
        return row>0;
    }

//查
    @Override
    public User find(Integer uid) {
        return userMapper.findById(uid);
    }

//查所有
    @Override
    public List<User> findall() {
        return userMapper.findAll();
    }
}

