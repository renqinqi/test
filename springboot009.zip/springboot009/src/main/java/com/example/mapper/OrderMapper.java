package com.example.mapper;

import com.example.pojo.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface OrderMapper {
    //增
    Integer add(@Param(value = "order0") Order order);
    //删
    Integer del(Integer oid);
    //改
    Integer update(@Param(value = "order1") Order order);
    //查
   Order findById(Integer oid);
   //查所有
    List<Order> findAll();

}
