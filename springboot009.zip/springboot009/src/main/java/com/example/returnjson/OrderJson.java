package com.example.returnjson;

import lombok.Data;

@Data
public class OrderJson {
    private Integer statue;
    private String info;
    private String data;
}
