import com.ioc.controller.UserController;
import com.ioc.service.UserService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    @org.junit.jupiter.api.Test
    public void test(){
        ApplicationContext appContext= new ClassPathXmlApplicationContext("spring-config.xml");
        UserController uc=appContext.getBean(UserController.class);
        System.out.println(uc.sum(6, 3));
    }
}
