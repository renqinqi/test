package com.example.controller;

import com.example.pojo.User;
import com.example.returnjson.UserFindJson;
import com.example.returnjson.UserFindallJson;
import com.example.returnjson.UserJson;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class Controller {
    @Autowired
    private UserService userService;
//增
    @PostMapping
    public UserJson add(@RequestBody User user){
        UserJson userJson=new UserJson();
        userJson.setStatue(200);
        userJson.setInfo("添加数据");
        userJson.setData("失败");
        boolean isOk=userService.add(user);
        if(isOk == true){
            userJson.setData("成功");
        }
        return userJson;
    }
//删
    @DeleteMapping("/{uid}")
    public UserJson del(@PathVariable Integer uid){
        boolean isOk=userService.del(uid);
        UserJson userJson=new UserJson();
        userJson.setStatue(200);
        userJson.setInfo("删除数据");
        userJson.setData("失败");
        if(isOk == true){
            userJson.setData("成功");
        }
        return userJson;

    }
//改
    @PutMapping
    public UserJson update(@RequestBody User user){
        boolean isOk=userService.update(user);
        UserJson userJson=new UserJson();
        userJson.setStatue(200);
        userJson.setInfo("修改数据");
        userJson.setData("失败");
        if(isOk == true){
            userJson.setData("成功");
        }
        return userJson;
    }
//查
    @GetMapping("/{uid}")
    public UserFindJson find(@PathVariable Integer uid){
      User user= userService.find(uid);
      UserFindJson userFindJson=new UserFindJson();
      userFindJson.setStatue(200);
      userFindJson.setInfo("数据查询");
      userFindJson.setUser(user);
      return userFindJson;
    }
//查所有
    @GetMapping
    public UserFindallJson findall(){
        List<User> users=userService.findall();
        UserFindallJson userFindallJson=new UserFindallJson();
        userFindallJson.setStatue(200);
        userFindallJson.setInfo("查询所有数据");
        userFindallJson.setListUser(users);
        return userFindallJson;
    }

}
