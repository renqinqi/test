package com.example.returnjson;

import com.example.pojo.Order;
import lombok.Data;

import java.util.List;
@Data
public class OrderFindallJson {
    private Integer statue;
    private String info;
    private List<Order> listOrder;
}
