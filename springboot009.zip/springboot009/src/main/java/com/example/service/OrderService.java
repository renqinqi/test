package com.example.service;

import com.example.pojo.Order;

import java.util.List;

public interface OrderService {
    //增
    Boolean add(Order order);
    //删
    Boolean del(Integer oid);
    //改
    Boolean update(Order order);
    //查
    Order find(Integer oid);
    //查所有
    List<Order> findall();
}
