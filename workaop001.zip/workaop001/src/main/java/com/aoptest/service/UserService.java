package com.aoptest.service;

public interface UserService {
//    写一个业务层的接口,接口里面有5个方法
    void sayHello1();
    void sayHello2();
    void sayHello3();
    void sayHello5();
    void sayHello6();
}
