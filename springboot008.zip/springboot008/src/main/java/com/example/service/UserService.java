package com.example.service;

import com.example.pojo.User;

import java.util.List;

public interface UserService {
//增
    Boolean add(User user);
//删
    Boolean del(Integer uid);
//改
    Boolean update(User user);
//查
    User find(Integer uid);
//查所有
    List<User> findall();


}
