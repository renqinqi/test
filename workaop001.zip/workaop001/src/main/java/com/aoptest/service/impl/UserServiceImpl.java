package com.aoptest.service.impl;

import com.aoptest.service.UserService;
import org.springframework.stereotype.Service;

@Service("uservice")
public class UserServiceImpl implements UserService {
//    写一个业务层的实现类,实现类里面具体实现功能
    @Override
    public void sayHello1() {
        System.out.println("hello aop1");
    }

    @Override
    public void sayHello2() {
        System.out.println("hello aop2");
    }

    @Override
    public void sayHello3() {
        System.out.println("hello aop3");
    }

    @Override
    public void sayHello5() {
        System.out.println("hello aop5");
//        System.out.println(5/0);
    }

    @Override
    public void sayHello6() {
        System.out.println("hello aop6");
    }
}
