package com.example.mapper;

import com.example.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {
//增
    Integer add(@Param(value = "user0") User user);
//删
    Integer del(Integer uid);
//改
    Integer update(@Param(value = "user1") User user);
//查
    User findById(Integer uid);
//查所有
    List<User> findAll();
}
