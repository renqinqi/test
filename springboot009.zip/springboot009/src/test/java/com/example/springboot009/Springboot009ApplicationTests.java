package com.example.springboot009;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot009ApplicationTests {

    @Test
    void contextLoads() {
    }

}
