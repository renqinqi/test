package com.example.returnjson;

import lombok.Data;

@Data
public class UserJson {
    private Integer statue;
    private String info;
    private String data;
}
