package com.example.returnjson;

import com.example.pojo.User;
import lombok.Data;

import java.util.List;

@Data
public class UserFindallJson {
    private Integer statue;
    private String info;
    private List<User> listUser;

}
