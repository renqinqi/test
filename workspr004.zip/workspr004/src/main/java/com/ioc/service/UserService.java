package com.ioc.service;

public interface UserService {
    double sum(double num1,double num2);
}
