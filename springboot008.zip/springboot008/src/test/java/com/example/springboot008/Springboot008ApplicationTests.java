package com.example.springboot008;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot008ApplicationTests {

    @Test
    void contextLoads() {
    }

}
