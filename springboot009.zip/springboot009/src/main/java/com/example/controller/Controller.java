package com.example.controller;

import com.example.pojo.Order;
import com.example.returnjson.OrderFindJson;
import com.example.returnjson.OrderFindallJson;
import com.example.returnjson.OrderJson;
import com.example.service.OrderService;
import com.sun.org.apache.xpath.internal.operations.Or;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class Controller {
    @Autowired
    private OrderService orderService;
//    增
    @PostMapping
    public OrderJson add(@RequestBody Order order){
        OrderJson orderJson=new OrderJson();
        orderJson.setStatue(200);
        orderJson.setInfo("添加数据");
        orderJson.setData("失败");
        boolean isOk=orderService.add(order);
        if(isOk==true){
            orderJson.setData("成功");
        }
        return orderJson;
    }

//    删
    @DeleteMapping("/{oid}")
    public OrderJson del(@PathVariable Integer oid){
        OrderJson orderJson=new OrderJson();
        orderJson.setStatue(200);
        orderJson.setInfo("删除数据");
        orderJson.setData("失败");
        boolean isOk=orderService.del(oid);
        if(isOk==true){
            orderJson.setData("成功");
        }
        return orderJson;
    }

//    改
    @PutMapping
    public OrderJson update(@RequestBody Order order){
        OrderJson orderJson=new OrderJson();
        orderJson.setStatue(200);
        orderJson.setInfo("修改数据");
        orderJson.setData("失败");
        boolean isOk=orderService.update(order);
        if(isOk==true){
            orderJson.setData("成功");
        }
        return orderJson;
    }


//    查
    @GetMapping("/{oid}")
    public OrderFindJson find(@PathVariable Integer oid){
        Order order=orderService.find(oid);
        OrderFindJson orderFindJson=new OrderFindJson();
        OrderJson orderFJson=new OrderJson();
        orderFindJson.setStatue(200);
        orderFindJson.setInfo("查询数据");
        orderFindJson.setOrder(order);
        return orderFindJson;

    }

//    查所有
    @GetMapping
    public OrderFindallJson finadll(){
        List<Order> orders=orderService.findall();
        OrderFindallJson orderFindallJson=new OrderFindallJson();
        orderFindallJson.setStatue(200);
        orderFindallJson.setInfo("查询所有数据");
        orderFindallJson.setListOrder(orders);
        return orderFindallJson;

    }



}
