import com.aoptest.config.AppConfig;
import com.aoptest.service.UserService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
    @org.junit.jupiter.api.Test
    public void test(){
        ApplicationContext app= new AnnotationConfigApplicationContext(AppConfig.class);
        UserService userService= (UserService) app.getBean("uservice");
        userService.sayHello1();
        userService.sayHello2();
        userService.sayHello3();
        userService.sayHello5();
        userService.sayHello6();
    }
}
