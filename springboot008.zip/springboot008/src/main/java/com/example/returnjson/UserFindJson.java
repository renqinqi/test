package com.example.returnjson;

import com.example.pojo.User;
import lombok.Data;

@Data
public class UserFindJson {
    private Integer statue;
    private String info;
    private User user;
}
